import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

/// Design tokens for English Duel.
/// All visual constants flow from here — no magic numbers in widgets.
/// Changing a token value here updates the entire app consistently.

// ─── Colors ───────────────────────────────────────────────────
/// Blue + warm cream palette.
/// Blue = trust, competition, clarity. Cream = warmth, premium feel.
abstract final class ColorTokens {
  // Background & surface
  static const background = Color(0xFFF6F8F6);
  static const surface = Color(0xFFFFFFFF);
  static const surfaceGrey = Color(0xFFEDE7D9);
  static const border = Color(0xFFE0D8C8);

  // Primary blue
  static const primary = Color(0xFF3B82F6);
  static const primaryDark = Color(0xFF2563EB);
  static const primaryLight = Color(0xFFDBEAFE);

  // Text
  static const textPrimary = Color(0xFF1A1A2E);
  static const textSecondary = Color(0xFF6B7280);

  // Status
  static const success = Color(0xFF10B981);
  static const danger = Color(0xFFEF4444);
  static const warning = Color(0xFFF59E0B);

  // Rank — podium colors
  static const gold = Color(0xFFF59E0B);
  static const goldSoft = Color(0xFFFFF8E1);
  static const silver = Color(0xFF9CA3AF);
  static const silverSoft = Color(0xFFF3F4F6);
  static const bronze = Color(0xFFCD7F32);
  static const bronzeSoft = Color(0xFFFFF0E0);
}

// ─── Spacing (8pt grid) ───────────────────────────────────────
/// Consistent spacing scale based on 8pt grid.
abstract final class SpacingTokens {
  static const double xs = 4;
  static const double sm = 8;
  static const double md = 12;
  static const double base = 16;
  static const double lg = 20;
  static const double xl = 24;
  static const double xxl = 32;
}

// ─── Radius ───────────────────────────────────────────────────
/// Controlled, not bubbly. Reduced from previous values.
abstract final class RadiusTokens {
  static const small = BorderRadius.all(Radius.circular(8));
  static const medium = BorderRadius.all(Radius.circular(12));
  static const card = BorderRadius.all(Radius.circular(16));
  static const large = BorderRadius.all(Radius.circular(20));
  static const pill = BorderRadius.all(Radius.circular(100));
}

// ─── Elevation / Shadows ──────────────────────────────────────
/// Dual-layer shadows for visible depth on warm background.
abstract final class ElevationTokens {
  static List<BoxShadow> get soft => const [
        BoxShadow(
          color: Color(0x08000000),
          blurRadius: 8,
          offset: Offset(0, 1),
        ),
        BoxShadow(
          color: Color(0x10000000),
          blurRadius: 20,
          offset: Offset(0, 4),
        ),
      ];

  static List<BoxShadow> get elevated => const [
        BoxShadow(
          color: Color(0x0A000000),
          blurRadius: 10,
          offset: Offset(0, 2),
        ),
        BoxShadow(
          color: Color(0x14000000),
          blurRadius: 32,
          offset: Offset(0, 8),
        ),
      ];

  /// Colored glow for primary buttons.
  static List<BoxShadow> primaryGlow([double opacity = 0.3]) => [
        BoxShadow(
          color: ColorTokens.primary.withValues(alpha: opacity),
          blurRadius: 16,
          offset: const Offset(0, 4),
        ),
      ];
}

// ─── Typography ───────────────────────────────────────────────
/// Plus Jakarta Sans — modern geometric sans with premium feel.
/// Tighter letter-spacing, heavier weights for headlines.
abstract final class TextStyles {
  static String? get _fontFamily =>
      GoogleFonts.plusJakartaSans().fontFamily;

  static TextStyle get headlineLarge => TextStyle(
        fontFamily: _fontFamily,
        fontSize: 28,
        fontWeight: FontWeight.w800,
        color: ColorTokens.textPrimary,
        height: 1.15,
        letterSpacing: -0.5,
      );

  static TextStyle get headlineMedium => TextStyle(
        fontFamily: _fontFamily,
        fontSize: 22,
        fontWeight: FontWeight.w700,
        color: ColorTokens.textPrimary,
        height: 1.2,
        letterSpacing: -0.3,
      );

  static TextStyle get titleLarge => TextStyle(
        fontFamily: _fontFamily,
        fontSize: 18,
        fontWeight: FontWeight.w700,
        color: ColorTokens.textPrimary,
      );

  static TextStyle get titleMedium => TextStyle(
        fontFamily: _fontFamily,
        fontSize: 16,
        fontWeight: FontWeight.w600,
        color: ColorTokens.textPrimary,
      );

  static TextStyle get bodyLarge => TextStyle(
        fontFamily: _fontFamily,
        fontSize: 16,
        fontWeight: FontWeight.w400,
        color: ColorTokens.textPrimary,
        letterSpacing: -0.1,
      );

  static TextStyle get bodyMedium => TextStyle(
        fontFamily: _fontFamily,
        fontSize: 14,
        fontWeight: FontWeight.w400,
        color: ColorTokens.textSecondary,
      );

  static TextStyle get labelLarge => TextStyle(
        fontFamily: _fontFamily,
        fontSize: 14,
        fontWeight: FontWeight.w600,
        color: ColorTokens.textPrimary,
      );

  static TextStyle get caption => TextStyle(
        fontFamily: _fontFamily,
        fontSize: 12,
        fontWeight: FontWeight.w500,
        color: ColorTokens.textSecondary,
      );
}

// ─── Animation Durations ──────────────────────────────────────
abstract final class DurationTokens {
  static const quick = Duration(milliseconds: 150);
  static const normal = Duration(milliseconds: 200);
  static const medium = Duration(milliseconds: 300);
}
