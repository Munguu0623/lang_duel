import 'package:flutter/material.dart';

import '../../core/theme/tokens.dart';
import 'primary_button.dart';

/// Generic error state UI: icon + title + subtitle + primary action.
class ErrorState extends StatelessWidget {
  const ErrorState({
    super.key,
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.actionLabel,
    this.onAction,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: SpacingTokens.xxl),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Container(
              width: 72,
              height: 72,
              decoration: const BoxDecoration(
                color: ColorTokens.surfaceGrey,
                shape: BoxShape.circle,
              ),
              child: Icon(icon, size: 32, color: ColorTokens.danger),
            ),
            const SizedBox(height: SpacingTokens.lg),
            Text(
              title,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.titleLarge,
            ),
            const SizedBox(height: SpacingTokens.sm),
            Text(
              subtitle,
              textAlign: TextAlign.center,
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: SpacingTokens.xl),
            PrimaryButton(
              label: actionLabel,
              onPressed: onAction,
              expanded: false,
              size: ButtonSize.sm,
            ),
          ],
        ),
      ),
    );
  }
}

