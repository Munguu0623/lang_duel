import 'package:flutter/material.dart';

import '../../core/theme/tokens.dart';

/// 44x44 rounded-square icon button with subtle background and ripple.
class GhostIconButton extends StatelessWidget {
  const GhostIconButton({
    super.key,
    required this.icon,
    this.onTap,
  });

  final IconData icon;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: ColorTokens.surface,
      borderRadius: RadiusTokens.small,
      child: InkWell(
        onTap: onTap,
        borderRadius: RadiusTokens.small,
        child: Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            borderRadius: RadiusTokens.small,
            border: Border.all(color: ColorTokens.border, width: 1),
          ),
          child: Icon(icon, size: 20, color: ColorTokens.textPrimary),
        ),
      ),
    );
  }
}
