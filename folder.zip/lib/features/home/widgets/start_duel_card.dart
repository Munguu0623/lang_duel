import 'package:flutter/material.dart';

import '../../../core/theme/tokens.dart';
import '../../../ui/widgets/pressable_scale.dart';
import '../../../ui/widgets/primary_button.dart';

/// Big CTA card — "Start a Duel" with subtitle and Quick Duel button.
class StartDuelCard extends StatelessWidget {
  const StartDuelCard({
    super.key,
    required this.onStartDuel,
  });

  final VoidCallback onStartDuel;

  @override
  Widget build(BuildContext context) {
    return PressableScale(
      onTap: onStartDuel,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.all(SpacingTokens.xl),
        decoration: BoxDecoration(
          color: ColorTokens.surface,
          borderRadius: RadiusTokens.card,
          boxShadow: ElevationTokens.soft,
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Icon badge
            Container(
              width: 48,
              height: 48,
              decoration: BoxDecoration(
                color: ColorTokens.primaryLight,
                borderRadius: RadiusTokens.small,
              ),
              child: const Icon(
                Icons.bolt_rounded,
                size: 24,
                color: ColorTokens.primary,
              ),
            ),
            const SizedBox(height: SpacingTokens.base),
            Text(
              'Start a Duel',
              style: Theme.of(context).textTheme.headlineMedium,
            ),
            const SizedBox(height: SpacingTokens.xs),
            Text(
              '60 seconds. AI judges.',
              style: Theme.of(context).textTheme.bodyMedium,
            ),
            const SizedBox(height: SpacingTokens.lg),
            PrimaryButton(
              label: 'Quick Duel',
              onPressed: onStartDuel,
            ),
          ],
        ),
      ),
    );
  }
}
