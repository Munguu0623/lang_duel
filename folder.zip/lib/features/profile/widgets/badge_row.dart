import 'package:flutter/material.dart';

import '../../../core/theme/tokens.dart';
import '../../../mock/fake_models.dart';

/// Horizontal scrollable row of badge items.
class BadgeRow extends StatelessWidget {
  const BadgeRow({
    super.key,
    required this.badges,
  });

  final List<DuelBadge> badges;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 80,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: badges.length,
        separatorBuilder: (_, _) => const SizedBox(width: SpacingTokens.md),
        itemBuilder: (_, index) => _BadgeItem(badge: badges[index]),
      ),
    );
  }
}

class _BadgeItem extends StatelessWidget {
  const _BadgeItem({required this.badge});

  final DuelBadge badge;

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 48,
          height: 48,
          decoration: const BoxDecoration(
            color: ColorTokens.primaryLight,
            shape: BoxShape.circle,
          ),
          child: Center(
            child: Icon(
              _iconForBadge(badge.icon),
              size: 22,
              color: ColorTokens.primary,
            ),
          ),
        ),
        const SizedBox(height: SpacingTokens.xs),
        Text(
          badge.label,
          style: TextStyles.caption,
          overflow: TextOverflow.ellipsis,
        ),
      ],
    );
  }

  IconData _iconForBadge(String icon) {
    return switch (icon) {
      '1' => Icons.emoji_events_rounded,
      '2' => Icons.local_fire_department_rounded,
      '3' => Icons.record_voice_over_rounded,
      '4' => Icons.forum_rounded,
      '5' => Icons.spellcheck_rounded,
      _ => Icons.star_rounded,
    };
  }
}
