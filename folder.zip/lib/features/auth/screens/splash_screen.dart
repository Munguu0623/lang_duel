import 'dart:async';

import 'package:flutter/material.dart';

import '../../../app/routes.dart';
import '../../../core/motion/motion.dart';
import '../../../core/theme/tokens.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({super.key});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen>
    with SingleTickerProviderStateMixin {
  late final AnimationController _fadeController;

  @override
  void initState() {
    super.initState();
    _fadeController = AnimationController(
      vsync: this,
      duration: MotionDurations.med,
    )..forward();

    // Fake splash + version check.
    Timer(const Duration(milliseconds: 1500), () async {
      await Future<void>.delayed(const Duration(milliseconds: 600));
      if (!mounted) return;
      Navigator.of(context).pushReplacementNamed(Routes.onboarding);
    });
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: ColorTokens.background,
      body: FadeTransition(
        opacity: _fadeController,
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Container(
                padding: const EdgeInsets.symmetric(
                  horizontal: SpacingTokens.xxl,
                  vertical: SpacingTokens.md,
                ),
                decoration: BoxDecoration(
                  color: ColorTokens.surface,
                  borderRadius: RadiusTokens.card,
                  boxShadow: ElevationTokens.soft,
                ),
                child: const Text(
                  'ENGLISH DUEL',
                  style: TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    letterSpacing: 1.2,
                    color: ColorTokens.textPrimary,
                  ),
                ),
              ),
              const SizedBox(height: SpacingTokens.lg),
              Text(
                'AI-powered voice battles',
                style: TextStyles.bodyMedium,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

