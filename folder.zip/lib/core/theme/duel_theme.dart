import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

import 'tokens.dart';

/// Builds the app-wide ThemeData from design tokens.
/// Every visual property flows from tokens — no local magic numbers.
class DuelTheme {
  DuelTheme._();

  static ThemeData get light {
    final baseTextTheme = GoogleFonts.plusJakartaSansTextTheme();

    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: ColorTokens.background,

      // ─── Color Scheme ──────────────────────────────────────
      colorScheme: ColorScheme.light(
        primary: ColorTokens.primary,
        surface: ColorTokens.background,
        onPrimary: Colors.white,
        onSurface: ColorTokens.textPrimary,
      ),

      // ─── Typography ────────────────────────────────────────
      textTheme: baseTextTheme.copyWith(
        headlineLarge: TextStyles.headlineLarge,
        headlineMedium: TextStyles.headlineMedium,
        titleLarge: TextStyles.titleLarge,
        titleMedium: TextStyles.titleMedium,
        bodyLarge: TextStyles.bodyLarge,
        bodyMedium: TextStyles.bodyMedium,
        labelLarge: TextStyles.labelLarge,
      ),

      // ─── AppBar ───────────────────────────────────────────
      appBarTheme: AppBarTheme(
        backgroundColor: ColorTokens.background,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: true,
        titleTextStyle: TextStyles.titleLarge,
        iconTheme: const IconThemeData(color: ColorTokens.textPrimary),
      ),

      // ─── Card ─────────────────────────────────────────────
      cardTheme: CardThemeData(
        color: ColorTokens.surface,
        elevation: 0,
        shape: RoundedRectangleBorder(borderRadius: RadiusTokens.card),
        margin: EdgeInsets.zero,
      ),

      // ─── Elevated Button (Primary) ────────────────────────
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          backgroundColor: ColorTokens.primary,
          foregroundColor: Colors.white,
          disabledBackgroundColor: ColorTokens.surfaceGrey,
          disabledForegroundColor: ColorTokens.textSecondary,
          elevation: 0,
          shape: const StadiumBorder(),
          padding: const EdgeInsets.symmetric(
            horizontal: SpacingTokens.xl,
            vertical: SpacingTokens.md,
          ),
          textStyle: TextStyles.titleMedium.copyWith(color: Colors.white),
        ),
      ),

      // ─── Outlined Button ──────────────────────────────────
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          foregroundColor: ColorTokens.textPrimary,
          shape: const StadiumBorder(),
          side: const BorderSide(color: ColorTokens.border),
          padding: const EdgeInsets.symmetric(
            horizontal: SpacingTokens.xl,
            vertical: SpacingTokens.md,
          ),
          textStyle: TextStyles.titleMedium,
        ),
      ),

      // ─── Text Button ──────────────────────────────────────
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          foregroundColor: ColorTokens.primary,
          shape: const StadiumBorder(),
          textStyle: TextStyles.labelLarge,
        ),
      ),

      // ─── Chip ─────────────────────────────────────────────
      chipTheme: ChipThemeData(
        backgroundColor: ColorTokens.surfaceGrey,
        selectedColor: ColorTokens.primary,
        labelStyle: TextStyles.bodyMedium,
        secondaryLabelStyle: TextStyles.bodyMedium.copyWith(
          color: Colors.white,
        ),
        shape: const StadiumBorder(),
        padding: const EdgeInsets.symmetric(
          horizontal: SpacingTokens.md,
          vertical: SpacingTokens.xs,
        ),
        side: BorderSide.none,
      ),

      // ─── Page Transitions ─────────────────────────────────
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
          TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
          TargetPlatform.linux: FadeUpwardsPageTransitionsBuilder(),
        },
      ),
    );
  }
}
