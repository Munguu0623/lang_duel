import 'package:flutter/material.dart';

import '../../../app/routes.dart';
import '../../../core/theme/tokens.dart';
import '../../../features/auth/auth_flow_controller.dart';
import '../../../ui/widgets/soft_card.dart';

/// Auth method selection — Apple, Google, or Guest.
/// One primary action per card, guest as a subtle text button.
class AuthChoiceScreen extends StatelessWidget {
  const AuthChoiceScreen({super.key});

  void _goNext(BuildContext context, {required bool isGuest}) {
    authFlowController
      ..isGuest = isGuest
      ..username = null;
    Navigator.of(context).pushNamed(Routes.username);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: SpacingTokens.base),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: SpacingTokens.xxl),
              Text(
                'Enter the Arena',
                style: Theme.of(context).textTheme.headlineLarge,
              ),
              const SizedBox(height: SpacingTokens.sm),
              Text(
                'Choose how you want to start your first duel.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: SpacingTokens.xxl),
              SoftCard(
                onTap: () => _goNext(context, isGuest: false),
                leadingIcon: Icons.apple_rounded,
                child: Text(
                  'Continue with Apple',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              const SizedBox(height: SpacingTokens.md),
              SoftCard(
                onTap: () => _goNext(context, isGuest: false),
                leadingIcon: Icons.g_mobiledata_rounded,
                child: Text(
                  'Continue with Google',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ),
              const Spacer(),
              Center(
                child: TextButton(
                  onPressed: () => _goNext(context, isGuest: true),
                  child: const Text(
                    'Continue as guest',
                    style: TextStyle(
                      fontSize: 14,
                      fontWeight: FontWeight.w500,
                      color: ColorTokens.textSecondary,
                    ),
                  ),
                ),
              ),
              const SizedBox(height: SpacingTokens.xxl),
            ],
          ),
        ),
      ),
    );
  }
}
