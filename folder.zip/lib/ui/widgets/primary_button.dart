import 'package:flutter/material.dart';

import '../../core/motion/motion.dart';
import '../../core/theme/tokens.dart';
import 'haptics.dart';
import 'pressable_scale.dart';

enum ButtonSize { sm, md, lg }

/// Primary action button with gradient, colored shadow, and loading state.
class PrimaryButton extends StatelessWidget {
  const PrimaryButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.expanded = true,
    this.size = ButtonSize.md,
    this.isLoading = false,
  });

  final String label;
  final VoidCallback? onPressed;
  final bool expanded;
  final ButtonSize size;
  final bool isLoading;

  double get _height => switch (size) {
        ButtonSize.sm => 44,
        ButtonSize.md => 48,
        ButtonSize.lg => 56,
      };

  double get _fontSize => switch (size) {
        ButtonSize.sm => 14,
        ButtonSize.md => 16,
        ButtonSize.lg => 18,
      };

  @override
  Widget build(BuildContext context) {
    final enabled = !isLoading && onPressed != null;

    final button = PressableScale(
      enabled: enabled,
      onTap: enabled
          ? () async {
              await Haptics.lightTap();
              onPressed?.call();
            }
          : null,
      child: Container(
        height: _height,
        decoration: BoxDecoration(
          gradient: enabled
              ? const LinearGradient(
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                  colors: [ColorTokens.primary, ColorTokens.primaryDark],
                )
              : null,
          color: enabled ? null : ColorTokens.surfaceGrey,
          borderRadius: RadiusTokens.pill,
          boxShadow: enabled ? ElevationTokens.primaryGlow(0.25) : null,
        ),
        child: Center(
          child: AnimatedSwitcher(
            duration: MotionDurations.med,
            child: isLoading
                ? SizedBox(
                    key: const ValueKey('loading'),
                    width: _fontSize + 4,
                    height: _fontSize + 4,
                    child: const CircularProgressIndicator(
                      strokeWidth: 2,
                      valueColor:
                          AlwaysStoppedAnimation<Color>(Colors.white),
                    ),
                  )
                : Text(
                    key: const ValueKey('label'),
                    label,
                    style: TextStyle(
                      fontSize: _fontSize,
                      fontWeight: FontWeight.w700,
                      color: enabled
                          ? Colors.white
                          : ColorTokens.textSecondary,
                    ),
                  ),
          ),
        ),
      ),
    );

    return expanded ? SizedBox(width: double.infinity, child: button) : button;
  }
}
