import 'package:flutter/material.dart';

import '../../core/theme/tokens.dart';

enum StatPillVariant { neutral, primarySoft, successSoft }

/// Small pill for displaying rank, win rate, streak, or badge info.
class StatPill extends StatelessWidget {
  const StatPill({
    super.key,
    required this.label,
    this.icon,
    this.variant = StatPillVariant.neutral,
  });

  final String label;
  final IconData? icon;
  final StatPillVariant variant;

  Color get _bg => switch (variant) {
        StatPillVariant.neutral => ColorTokens.surfaceGrey,
        StatPillVariant.primarySoft => ColorTokens.primaryLight,
        StatPillVariant.successSoft => ColorTokens.success.withValues(alpha: 0.1),
      };

  Color get _fg => switch (variant) {
        StatPillVariant.neutral => ColorTokens.textSecondary,
        StatPillVariant.primarySoft => ColorTokens.primary,
        StatPillVariant.successSoft => ColorTokens.success,
      };

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(
        horizontal: SpacingTokens.md,
        vertical: SpacingTokens.xs,
      ),
      decoration: ShapeDecoration(color: _bg, shape: const StadiumBorder()),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          if (icon != null) ...[
            Icon(icon, size: 14, color: _fg),
            const SizedBox(width: SpacingTokens.xs),
          ],
          Text(
            label,
            style: TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: _fg,
            ),
          ),
        ],
      ),
    );
  }
}
